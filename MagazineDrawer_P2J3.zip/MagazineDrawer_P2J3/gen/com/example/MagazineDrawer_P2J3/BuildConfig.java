/** Automatically generated file. DO NOT MODIFY */
package com.example.MagazineDrawer_P2J3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}